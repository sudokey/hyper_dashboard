(function () {
  'use strict';

  window.app = {};
})();